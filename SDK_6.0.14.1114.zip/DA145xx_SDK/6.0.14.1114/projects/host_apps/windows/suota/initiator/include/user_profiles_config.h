/**
 ****************************************************************************************
 *
 * @file user_profiles_config.h
 *
 * @brief Profile configuration file.
 *
 * Copyright (C) 2014-2019 Dialog Semiconductor.
 * This computer program includes Confidential, Proprietary Information
 * of Dialog Semiconductor. All Rights Reserved.
 *
 ****************************************************************************************
 */

#ifndef USER_PROFILES_CONFIG_H_
#define USER_PROFILES_CONFIG_H_

#endif // USER_PROFILES_CONFIG_H_
